<?php

namespace App\Controllers;

use App\Models\UserModel;

class User extends BaseController
{
	public function __construct()
	{
		//we use default database in .env
    $db = db_connect();
    $this->userModel = new UserModel($db);
	}


	public function testMVC()
	{
		$result = $this->userModel->checkMVC();
    $data['results']=$result;
    $data['msg']="heyo welcome to the new world";
    echo view('testViewMVC', $data);
  	}

		public function add()
		{
			echo view('add');
		}

		public function save()
		{
			$first_name = $this->request->getPost('txtFirstName');
			$last_name = $this->request->getPost('txtLastName');
			$email = $this->request->getPost('txtEmail');
		

		$data = [
			'firstname'=> $first_name,
			'lastname' => $last_name,
			'email'    => $email,
		];

		$result = $this->userModel->add($data);
		if ($result) {
			echo "New User is registered succesfully.";
		} 
		else 
		{
		echo "Something went wrong";
	}
}
}