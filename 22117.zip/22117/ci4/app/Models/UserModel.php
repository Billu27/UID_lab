<?php 
namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
  
    function checkMVC()
    {
    return $this->db->query("SELECT * FROM userz")->getResult();
  }

  function add($data)
  {
    return $this->db
    ->table('user_info')
    ->insert( $data);
  }
}
